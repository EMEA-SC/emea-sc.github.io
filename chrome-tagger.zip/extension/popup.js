
document.addEventListener("DOMContentLoaded", function(event) {


  var button = document.getElementById('submit');
  button.onclick = function() {
    
    var account = document.getElementById("anumber").value;
    var urls = document.getElementById("urls").value;
    var oauth = document.getElementById("auth").value;
    var section = document.getElementById("section").value;
    var brandColour = document.getElementById("brand-colour").value;
    var agentTextColour = document.getElementById("agent-text-colour").value;

    chrome.storage.local.set({
      "LPaccount": account,
      "LPurls": urls,
      "LPoauth": oauth,
      "LPsection": section,
      "LPbrandColour": brandColour,
      "LPagentTextColour": agentTextColour,
      }, function() {
      console.log("values stored!");
    });

    window.close();

   


    // localStorage.setItem('lp_ext_account', account);
    // localStorage.setItem('lp_ext_urls', urls);
    // localStorage.setItem('lp_ext_oauth', oauth);
    // localStorage.setItem('lp_ext_section', section);
  };

  // var account = localStorage.getItem('lp_ext_account');
  // var urls = localStorage.getItem('lp_ext_urls');
  // var oauth = localStorage.getItem('lp_ext_oauth');
  // var section = localStorage.getItem('lp_ext_section');

  chrome.storage.local.get(["LPaccount","LPurls","LPoauth","LPsection","LPbrandColour","LPagentTextColour"], function(result) {
    console.log('Value currently is ' + JSON.stringify(result));
    if(result.LPaccount)
      document.getElementById("anumber").value = result.LPaccount;

    if(result.LPurls)
      document.getElementById("urls").value = result.LPurls;

    if(result.LPoauth)
      document.getElementById("auth").value = result.LPoauth;

    if(result.LPsection)
      document.getElementById("section").value = result.LPsection;

    if(result.LPbrandColour)
      document.getElementById("brand-colour").value = result.LPbrandColour;

    if(result.LPagentTextColour)
      document.getElementById("agent-text-colour").value = result.LPagentTextColour;
  });

  

});